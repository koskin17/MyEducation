import React from "react";

export function NotFound() {
  return <p className="title is-1 has-text-centered">Page not found</p>;
}
