import logging
from django.shortcuts import render

# Get logger for this module
logger = logging.getLogger(__name__)

# Create your views here.
