export function Companies() {
  return (
    <div className="max-w-lg mx-auto mt-10 p-8 text-center shadow-lg rounded-xl bg-white">
      <h1 className="text-3xl font-bold mb-4 text-gray-800">Companies</h1>
      <p className="text-gray-500 text-lg">Currently in development mode.</p>
    </div>
  );
}
