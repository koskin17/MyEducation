CREATE TABLE agents (
    agent_id INT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(50) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    commission_percentage NUMERIC NOT NULL
);
