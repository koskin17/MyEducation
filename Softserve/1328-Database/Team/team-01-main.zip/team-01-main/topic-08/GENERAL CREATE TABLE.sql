-- Зейкін Костянтин. Створення таблиці clients
CREATE TABLE clients (
    client_id SERIAL PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Зейкін Костянтин. Створення індексів для полів email и phone в таблиці clients, по яким, швидше за все,
-- шукатимуть інформацію про клієнта
CREATE INDEX idx_clients_email ON clients(email);
CREATE INDEX idx_clients_phone ON clients(phone);


-- Vasylkiv Ivan
CREATE TABLE resorts (
    resort_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(100) NOT NULL,
    quality INT NOT NULL,
    country VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL
);
