CREATE TABLE offers (
    offer_id SERIAL PRIMARY KEY,
    resort_id INT NOT NULL,
    cost NUMERIC NOT NULL,
    description TEXT,
    FOREIGN KEY (resort_id) REFERENCES resorts(resort_id)
);
