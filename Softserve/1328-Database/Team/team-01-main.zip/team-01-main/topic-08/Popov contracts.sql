CREATE TABLE contracts (
    contract_id SERIAL PRIMARY KEY,
    client_id INT NOT NULL,
    agent_id INT NOT NULL,
    resort_id INT NOT NULL,
    offer_id INT NOT NULL,
    sign_date DATE NOT NULL,
    rest_start DATE NOT NULL,
    rest_end DATE NOT NULL,
    FOREIGN KEY (client_id) REFERENCES clients(client_id),
    FOREIGN KEY (agent_id) REFERENCES agents(agent_id),
    FOREIGN KEY (resort_id) REFERENCES resorts(resort_id),
    FOREIGN KEY (offer_id) REFERENCES offers(offer_id)
);
