CREATE TABLE resorts (
    resort_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(100) NOT NULL,
    quality INT NOT NULL,
    country VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL
);
