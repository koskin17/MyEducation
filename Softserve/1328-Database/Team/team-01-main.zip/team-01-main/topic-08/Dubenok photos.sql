CREATE TABLE photos (
    photo_id INT PRIMARY KEY,
    resort_id INT NOT NULL,
    title VARCHAR NOT NULL,
    file_path VARCHAR NOT NULL,
    tags TEXT NOT NULL,
    FOREIGN KEY (resort_id) REFERENCES resorts(resort_id)
);
