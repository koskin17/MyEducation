CREATE TABLE comments(
  comment_id SERIAL PRIMARY KEY,
  photo_id INT NOT NULL,
  client_id INT NOT NULL,
  comment_text text NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  resort_id INT NOT NULL,

  FOREIGN KEY (photo_id) REFERENCES photos(photo_id),
  FOREIGN KEY (client_id) REFERENCES Clients(client_id),
  FOREIGN KEY (resort_id) REFERENCES resorts(resort_id)
)
