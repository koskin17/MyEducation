-- Зейкін Костянтин.
-- 1. Створення ролей
CREATE ROLE sales_manager_lead;
CREATE ROLE sales_manager;

-- 2. Створення користувачів
CREATE USER boss_sales WITH PASSWORD 'Boss123';
CREATE USER employee_sales WITH PASSWORD 'Employee123';

-- 3. Призначення ролей користувачам
GRANT sales_manager_lead TO boss_sales;
GRANT sales_manager TO employee_sales;

-- 4. Призначення дозволів ролям
-- Начальник відділу продажів (доступ для перегляду, вставки та оновлення клієнтів, агентів, контрактів та пропозицій
-- без можливості видалення записів з будь-якої таблиці для збереження інформації для майбутньої аналітики)
GRANT SELECT, INSERT, UPDATE ON clients, agents, contracts, offers TO sales_manager_lead;

-- Менеджер з продажу (може переглядати клієнтів та додавати нових, а також тільки переглядати контракти, пропозиції та агентів)
GRANT SELECT, INSERT ON clients TO sales_manager;
GRANT SELECT ON contracts, offers, agents TO sales_manager;

-- Васильків Іван
-- 1. Створення ролей
CREATE ROLE authorized_client;
CREATE ROLE guest_client;

-- 2. Створення користувачів
CREATE USER client1 WITH PASSWORD 'qwerty';
CREATE USER guest WITH PASSWORD 'guest';

-- 3. Призначення ролей користувачам
GRANT guest_client TO guest;
GRANT guest_client TO authorized_client;
GRANT authorized_client TO client1;

-- Гість (може переглядати курорти, пропозиції, фотографії та комментарі)
GRANT SELECT ON resorts, offers, photos, comments TO guest_client;

-- 4. Призначення дозволів ролям
-- Клієнт (може переглядати курорти, пропозиції, фотографії та комментарі
-- з можливістю додавання комментарів)
GRANT INSERT ON comments TO authorized_client;
GRANT USAGE, SELECT, UPDATE ON SEQUENCE comments_comment_id_seq TO authorized_client;

--Pliatsko Olya
-- 1. Створення ролей
CREATE ROLE comment_admin;
CREATE ROLE comment_moderator;

-- 2. Створення користувачів
CREATE USER chief_moderator WITH PASSWORD 'qwerty1234';
CREATE USER assistant_moderator WITH PASSWORD 'rewq654';

-- 3. Призначення ролей користувачам
GRANT comment_admin TO chief_moderator;
GRANT comment_moderator TO assistant_moderator;

-- 4. Призначення дозволів ролям
-- Адміністратор коментарів (може читати, додавати та редагувати коментарі, але не видаляти)
GRANT SELECT, INSERT, UPDATE ON comments TO comment_admin;

-- Модератор коментарів (може тільки читати та додавати коментарі)
GRANT SELECT, INSERT ON comments TO comment_moderator;


