-- Functions made for photos table
-- Getting photo by ID
CREATE FUNCTION get_photo_by_id(photo_id INT) 
RETURNS TABLE (photo_id INT, resort_id INT, title VARCHAR, file_path VARCHAR, tags TEXT) AS $$
BEGIN
    RETURN QUERY 
    SELECT photo_id, resort_id, title, file_path, tags
    FROM photos
    WHERE photos.photo_id = photo_id;
END;
$$ LANGUAGE plpgsql;

-- Getting all photos by resort ID
CREATE FUNCTION get_photos_by_resort(resort_id INT)
RETURNS TABLE (photo_id INT, resort_id INT, title VARCHAR, file_path VARCHAR, tags TEXT) AS $$
BEGIN
    RETURN QUERY
    SELECT photo_id, resort_id, title, file_path, tags
    FROM photos
    WHERE photos.resort_id = resort_id;
END;
$$ LANGUAGE plpgsql;

--Getting all photos by tag
CREATE FUNCTION get_photos_by_tag(tag TEXT)
RETURNS TABLE (photo_id INT, resort_id INT, title VARCHAR, file_path VARCHAR, tags TEXT) AS $$
BEGIN
    RETURN QUERY
    SELECT photo_id, resort_id, title, file_path, tags
    FROM photos
    WHERE tags LIKE '%' || tag || '%';
END;
$$ LANGUAGE plpgsql;

-- Two stored procedures with SELECT + INSERT
-- Insert a new photo into the photos table
CREATE OR REPLACE PROCEDURE insert_photo(
    p_resort_id INT,
    p_title VARCHAR,
    p_file_path VARCHAR,
    p_tags TEXT
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO photos (resort_id, title, file_path, tags)
    VALUES (p_resort_id, p_title, p_file_path, p_tags);
    
    -- Select the inserted photo
    SELECT * FROM photos
    WHERE resort_id = p_resort_id AND title = p_title;
END;
$$;

-- Insert a new photo and return the photo ID
CREATE OR REPLACE PROCEDURE insert_photo_and_return_id(
    p_resort_id INT,
    p_title VARCHAR,
    p_file_path VARCHAR,
    p_tags TEXT,
    OUT new_photo_id INT
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO photos (resort_id, title, file_path, tags)
    VALUES (p_resort_id, p_title, p_file_path, p_tags)
    RETURNING photo_id INTO new_photo_id;
END;
$$;

--Two stored procedures with UPDATE
-- Update the title of a photo by its photo_id
CREATE OR REPLACE PROCEDURE update_photo_title(
    p_photo_id INT,
    p_new_title VARCHAR
)
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE photos
    SET title = p_new_title
    WHERE photo_id = p_photo_id;
    
    -- select the updated photo
    SELECT * FROM photos WHERE photo_id = p_photo_id;
END;
$$;

-- Update the tags of a photo by its photo_id
CREATE OR REPLACE PROCEDURE update_photo_tags(
    p_photo_id INT,
    p_new_tags TEXT
)
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE photos
    SET tags = p_new_tags
    WHERE photo_id = p_photo_id;
    
    -- select the updated photo
    SELECT * FROM photos WHERE photo_id = p_photo_id;
END;
$$;

