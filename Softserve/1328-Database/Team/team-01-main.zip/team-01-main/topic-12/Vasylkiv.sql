CREATE FUNCTION number_contracts_for_resort_id(_id INT)
RETURNS NUMERIC AS $$
DECLARE 
	contracts_count INT;
BEGIN 
	SELECT COUNT(*) INTO contracts_count FROM contracts WHERE resort_id = _id;
	RETURN contracts_count;
END;
$$
LANGUAGE plpgsql;
----

CREATE FUNCTION photo_file_path_for_resort_id(_id INT)
RETURNS VARCHAR AS $$
BEGIN
	RETURN (SELECT file_path FROM photos WHERE resort_id = _id);
END;
$$
LANGUAGE plpgsql;
----

CREATE FUNCTION comments_by_resort_id(_id INT)
RETURNS TABLE (
	_resort_name VARCHAR,
	_comment_text TEXT,
	_authors_name VARCHAR
)
AS $$
BEGIN
	RETURN QUERY
	SELECT r.name, cm.comment_text, cl.full_name
	FROM resorts AS r
	JOIN comments AS cm ON r.resort_id = cm.resort_id
	JOIN clients AS cl ON cm.client_id = cl.client_id
	WHERE r.resort_id = _id;
END;
$$
LANGUAGE plpgsql;
----

CREATE PROCEDURE get_resorts_by_country(
    IN _country VARCHAR,
    OUT resort_id INT,
    OUT name VARCHAR,
    OUT type VARCHAR,
    OUT quality INT,
    OUT location VARCHAR
)
LANGUAGE plpgsql
AS $$
BEGIN
    SELECT r.resort_id, r.name, r.type, r.quality, r.location
    INTO resort_id, name, type, quality, location
    FROM resorts AS r
    WHERE r.country = _country;
END;
$$;
-----

CREATE PROCEDURE add_new_resort(
    _name VARCHAR, 
    _type VARCHAR, 
    _quality INT, 
    _country VARCHAR, 
    _location VARCHAR
)
LANGUAGE plpgsql
AS $$
BEGIN
    IF _quality < 1 OR _quality > 5 THEN
        RAISE EXCEPTION 'Quality must be between 1 and 5. Given: %', _quality;
    END IF;

    INSERT INTO resorts (name, type, quality, country, location) 
    VALUES (_name, _type, _quality, _country, _location);
    
    COMMIT;
END;
$$;
-----

CREATE PROCEDURE update_resort_name (
    _resort_id INT,
    _name VARCHAR
)
LANGUAGE plpgsql
AS $$
BEGIN
    IF NOT EXISTS (SELECT * FROM resorts WHERE resort_id = _resort_id) THEN
        RAISE EXCEPTION 'Resort with ID % not found', _resort_id;
    END IF;

    UPDATE resorts
    SET name = _name
    WHERE resort_id = _resort_id;
	
    COMMIT;
END;
$$;
----

CREATE PROCEDURE update_resort_quality (
    _resort_id INT,
    _quality INT
)
LANGUAGE plpgsql
AS $$
BEGIN
    IF NOT EXISTS (SELECT * FROM resorts WHERE resort_id = _resort_id) THEN
        RAISE EXCEPTION 'Resort with ID % not found', _resort_id;
    END IF;

    IF _quality < 1 OR _quality > 5 THEN
        RAISE EXCEPTION 'Quality must be between 1 and 5. Given: %', _quality;
    END IF;

    UPDATE resorts
    SET quality = _quality
    WHERE resort_id = _resort_id;
	
    COMMIT;
END;
$$;
