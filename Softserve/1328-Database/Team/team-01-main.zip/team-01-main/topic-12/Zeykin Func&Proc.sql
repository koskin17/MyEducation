-- 1.1. Функція отримання кількості клієнтів
CREATE FUNCTION get_clients_count()
RETURNS INT AS $$
DECLARE
    client_count INT;
BEGIN
    SELECT COUNT(*) INTO client_count FROM Clients;
    RETURN client_count;
END;
$$ LANGUAGE plpgsql;

-- 1.2. Функція отримання інформації про клієнта за ID
CREATE FUNCTION get_client_by_id(p_client_id INT)
RETURNS TABLE (full_name VARCHAR, email VARCHAR, phone VARCHAR) AS $$
BEGIN
    RETURN QUERY
        SELECT clients.full_name, clients.email, clients.phone FROM clients
        WHERE client_id = p_client_id;
END;
$$ LANGUAGE plpgsql;

-- 1.3. Функція перевірки існування email в базі
CREATE FUNCTION email_exists(p_email VARCHAR) RETURNS VARCHAR AS $$
DECLARE
    exists VARCHAR;
BEGIN
    SELECT p_email FROM clients
    WHERE clients.email = p_email INTO exists;
    RETURN exists;
END;
$$ LANGUAGE plpgsql;

-- 2.1. Процедура додавання нового клієнта
CREATE PROCEDURE add_client(
    p_full_name VARCHAR(255),
    p_email VARCHAR(50),
    p_phone VARCHAR(20)
)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Перевіряємо, чи існує вже такий email чи телефон
    IF EXISTS (SELECT p_email FROM clients WHERE clients.email = p_email OR clients.phone = p_phone) THEN
        RAISE EXCEPTION 'Клієнт із таким email або телефоном вже існує!';
    END IF;

    -- Вставка нового клієнта
    INSERT INTO clients (full_name, email, phone) VALUES (p_full_name, p_email, p_phone);
END;
$$;

-- 2.2. Пошук клієнта по email
CREATE PROCEDURE get_client_by_email(
    IN client_email VARCHAR,
    OUT client_id INT,
    OUT full_name VARCHAR,
    OUT phone VARCHAR,
    OUT created_at TIMESTAMP
)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Отримуємо дані клієнта
    SELECT c.client_id, c.full_name, c.phone, c.created_at 
    INTO client_id, full_name, phone, created_at
    FROM clients AS c
    WHERE c.email = client_email;
END;
$$;

-- 3.1. Процедура оновлення лише переданої інформації про клієнта.
CREATE PROCEDURE update_client_info(
    p_client_id INT,
    p_full_name VARCHAR(255) DEFAULT NULL,
    p_email VARCHAR(50) DEFAULT NULL,
    p_phone VARCHAR(20) DEFAULT NULL
)
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE Clients
    SET 
        full_name = COALESCE(p_full_name, full_name),
        email = COALESCE(p_email, email),
        phone = COALESCE(p_phone, phone)
    WHERE client_id = p_client_id;
END;
$$;

-- 3.2. Процедура поновлення тільки email клієнта
CREATE PROCEDURE update_client_email(
    p_client_id INT,
    p_new_email VARCHAR(50)
)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Перевіряємо, чи існує вже такий email
    IF EXISTS (SELECT p_new_email FROM clients WHERE clients.email = p_new_email) THEN
        RAISE EXCEPTION 'Email вже використовується іншим клієнтом!';
    END IF;

    -- Оновлюємо email клієнта
    UPDATE clients SET email = p_new_email WHERE client_id = p_client_id;
END;
$$;