INSERT INTO agents (agent_id, full_name, email, phone, commission_percentage) VALUES
('19678453','Ada Nevermore', 'adusik.never@gmail.com','+380508763784','15'),
('12563457','Leon Kannedy', 'leonchiktop@gmail.com', '+380507834562','17'),
('16735489','Simon Butter', 'simon228@gmail.com', '+3805083267289','14'),
('13785642','Price Yom', 'yomprice999@gmail.com', '+380503564127','19'),
('15327835','Mika Kanroji', 'mikatyan@gmail.com', '+380503956748','10'),
('12789354','Stacy Miracle', 'yastacy225@gmail.com', '+380506734892','20'),
('15243674','William Sparker', 'sparkerfire@gmail.com', '+380504738978','12'),
('19374562','Abdurahmed Iosipovich', 'abdurchik@gmail.com', '+380507758890','9'),
('18345263','Alka Bobruk', 'alkusik111@gmail.com', '+380506456787','11'),
('12463457','Albert Wesker', 'weskerimba@gmail.com', '+380504378969','20');
