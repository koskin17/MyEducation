INSERT INTO resorts (name, type, quality, country, location) VALUES
('Alpine Escape', 'Ski', 5, 'Switzerland', 'Alps'),
('Beach Paradise', 'Beach', 4, 'Maldives', 'Indian Ocean'),
('Mountain Retreat', 'Spa', 5, 'Canada', 'Rocky Mountains'),
('Safari Haven', 'Wildlife', 4, 'South Africa', 'Kruger National Park'),
('Desert Oasis', 'Luxury', 5, 'UAE', 'Dubai'),
('Rainforest Hideaway', 'Eco', 4, 'Costa Rica', 'Amazon Rainforest'),
('Island Getaway', 'Beach', 3, 'Thailand', 'Phuket'),
('Snowy Peaks', 'Ski', 5, 'France', 'French Alps'),
('Lakeside Serenity', 'Nature', 4, 'Italy', 'Lake Como'),
('Tropical Haven', 'Resort', 5, 'Hawaii', 'Maui');
