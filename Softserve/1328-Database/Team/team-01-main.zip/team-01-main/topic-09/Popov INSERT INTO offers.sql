INSERT INTO offers (resort_id, cost, description) VALUES
(1, 2500, 'Luxury ski package including all-day passes and gourmet dining.'),
(2, 1800, 'All-inclusive beachside retreat with private bungalow stay.'),
(3, 2200, 'Spa and wellness package with daily massages and yoga sessions.'),
(4, 1700, 'Wildlife safari experience with guided tours and premium lodging.'),
(5, 3000, 'Ultra-luxury desert escape with private villas and chauffeur service.'),
(6, 1600, 'Eco-friendly rainforest adventure with sustainable accommodations.'),
(7, 1400, 'Affordable island getaway with beachfront access and water sports.'),
(8, 2700, 'Exclusive ski resort package with private ski lessons.'),
(9, 2000, 'Scenic lakeside retreat with boat tours and fine dining.'),
(10, 2800, 'High-end tropical resort experience with luxury suites and spa.');  
