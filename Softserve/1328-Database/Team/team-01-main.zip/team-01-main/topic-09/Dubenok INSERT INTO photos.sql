INSERT INTO photos (photo_id, resort_id, title, file_path, tags) VALUES
('111', '1', 'holiday', '/images/travel_photos/AlpineEscape.jpg', 'Good place'),
('222', '2', 'vacation', '/images/travel_photos/BeachParadise.jpg', 'Thrilling'),
('333', '3', 'business meeting', '/images/travel_photos/MountainRetreat.jpg', 'Nice place'),
('444', '4', 'family trip', '/images/travel_photos/SafariHaven.jpg', 'Amazing'),
('555', '5', 'relaxation', '/images/travel_photos/DesertOasis.jpg', 'Chill'),
('666', '6','trip', '/images/travel_photos/RainforestHideaway.jpg', 'Dangerous'),
('777', '7', 'relaxation', '/images/travel_photos/IslandGetaway.jpg', 'Beautiful'),
('888', '8','weekend', '/images/travel_photos/SnowyPeaks.jpg', 'Sportic'),
('999', '9','trip', '/images/travel_photos/LakesideSerenity.jpg', 'Breathtaking'),
('1000', '10', 'vacation', '/images/travel_photos/TropicalHaven.jpg', 'Relaxing');
