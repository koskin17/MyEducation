INSERT INTO Clients (full_name, email, phone) VALUES
('John Doe', 'john.doe@example.com', '+123456789'),
('Alice Smith', 'alice.smith@example.com', '+987654321'),
('Robert Brown', 'robert.brown@example.com', '+192837465'),
('Emma White', 'emma.white@example.com', '+918273645'),
('Michael Green', 'michael.green@example.com', '+564738292'),
('Sophia Black', 'sophia.black@example.com', '+102938475'),
('David Johnson', 'david.johnson@example.com', '+564738291'),
('Olivia Moore', 'olivia.moore@example.com', '+675849302'),
('James Wilson', 'james.wilson@example.com', '+758493012'),
('Emily Davis', 'emily.davis@example.com', '+849302756');