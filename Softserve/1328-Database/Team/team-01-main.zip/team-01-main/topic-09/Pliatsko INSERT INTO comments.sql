INSERT INTO comments (photo_id, client_id, comment_text, created_at, resort_id)
VALUES
  (1, 1, 'Amazing view from the top!', '2025-02-24 10:00:00', 1),
  (2, 2, 'Had a wonderful time here, the weather was perfect.', '2025-02-24 11:00:00', 2),
  (3, 3, 'The resort could improve the cleanliness of the rooms.', '2025-02-24 12:00:00', 3),
  (4, 4, 'I loved the staff, they were so friendly.', '2025-02-24 13:00:00', 1),
  (5, 5, 'Great location but the food was below expectations.', '2025-02-24 14:00:00', 2),
  (6, 6, 'Best vacation ever! Highly recommend this place.', '2025-02-24 15:00:00', 3),
  (7, 7, 'The beach is beautiful, but the resort needs better services.', '2025-02-24 16:00:00', 1),
  (8, 8, 'Excellent facilities, but the rooms were a bit small.', '2025-02-24 17:00:00', 2),
  (9, 9, 'I had a relaxing time at the spa, it was rejuvenating.', '2025-02-24 18:00:00', 3),
  (10, 10, 'This resort is perfect for family vacations.', '2025-02-24 19:00:00', 1);
