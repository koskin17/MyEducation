---horizontal view---
CREATE VIEW horizontal_view AS
SELECT *
FROM resorts;

---vertical view---
CREATE VIEW vertical_view AS
SELECT name, country
FROM resorts;

---mixed view---
CREATE VIEW mixed_view AS
SELECT name
FROM resorts
WHERE resort_id IN (
    SELECT resort_id 
    FROM contracts 
    GROUP BY resort_id
    HAVING COUNT(*) > 3);
	
---joined view---
CREATE VIEW joined_view AS
SELECT r.name AS resort_name, c.contract_id, a.full_name AS agent_name
FROM resorts AS r
JOIN contracts AS c ON r.resort_id = c.resort_id
JOIN agents AS a ON c.agent_id = a.agent_id;

---subquery view---
CREATE VIEW subquery_view AS
SELECT r.name, r.country, (
	SELECT p.file_path 
	FROM photos AS p 
	WHERE p.resort_id = r.resort_id) AS file_path
FROM resorts AS r;

---union view---
CREATE VIEW union_view AS
SELECT full_name, 'Client' AS role FROM clients
UNION
SELECT full_name, 'Agent' AS role FROM agents;

---based on other view---
CREATE VIEW based_on_other_view AS
SELECT name, country
FROM horizontal_view
WHERE type = 'Ski';

---view with check option---
CREATE VIEW check_view AS
SELECT name, type, country
FROM resorts
WHERE quality = '5'
WITH CHECK OPTION;
