-- Horizontal View
CREATE VIEW Horizontal_View AS
SELECT client_id, full_name, email, phone
FROM Clients;

SELECT * FROM Horizontal_View

-- Vertical View
CREATE VIEW Vertical_View AS
SELECT full_name, email
FROM Clients;

SELECT * FROM Vertical_View

-- Mixed View
CREATE VIEW MixedView AS
SELECT client_id, full_name
FROM Clients
WHERE email LIKE '%example.com';

SELECT * FROM Mixed_View

-- View with Joining
CREATE VIEW ResortOffersView AS
SELECT resorts.name, offers.cost
FROM resorts
JOIN offers ON resorts.resort_id = offers.resort_id;

SELECT * FROM ResortOffersView

-- View with Subquery
CREATE VIEW Count_of_Orders_by_Client AS
SELECT client_id, full_name, (SELECT COUNT(*) FROM contracts WHERE contracts.client_id = clients.client_id) AS orders_count
FROM Clients;

SELECT * FROM Count_of_Orders_by_Client

--View with Union
CREATE VIEW Union_View AS
SELECT full_name, email FROM Clients
UNION
SELECT 'For_example', 'for_example@example.com';

SELECT * FROM Union_View

-- View on the Select from Another View
CREATE VIEW Top_Clients_View AS
SELECT client_id, full_name
FROM clients
WHERE client_id <= 2;

CREATE VIEW Detailed_Top_Clients_View AS
SELECT contracts.contract_id, Top_Clients_View.client_id AS client_id_top, contracts.agent_id,
contracts.resort_id, contracts.offer_id, contracts.sign_date, contracts.rest_start, contracts.rest_end
FROM Top_Clients_View
JOIN contracts ON Top_Clients_View.client_id = contracts.client_id;

SELECT * FROM Detailed_Top_Clients_View

-- View with Check Option
CREATE VIEW Active_Clients_View AS
SELECT client_id, full_name, email, phone
FROM Clients
WHERE email LIKE '%example.com'
WITH CHECK OPTION;

SELECT * FROM Active_Clients_View
