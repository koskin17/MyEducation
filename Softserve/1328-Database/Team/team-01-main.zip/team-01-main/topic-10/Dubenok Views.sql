--Horizontal View--
CREATE VIEW horizontal_view AS
SELECT agent_id, full_name, email, phone, commission_percentage
FROM agents;

--Vertical View--
CREATE VIEW vertical_view AS
SELECT full_name, email
FROM agents;

--Mixed View--
CREATE VIEW mixed_view AS
SELECT 
    agent_id, 
    full_name, 
    CONCAT('Email: ', email) AS contact_email, 
    CONCAT('Phone: ', phone) AS contact_phone, 
    commission_percentage
FROM agents;

--View with Joining--
CREATE VIEW view_with_joining AS
SELECT 
    a.agent_id, 
    a.full_name AS agent_name,
    a.phone AS agent_phone,
    c.client_id, 
    c.full_name AS client_name,
    c.phone AS client_phone
FROM agents a
JOIN Clients c ON a.phone = c.phone;

--View with Subquery--
CREATE VIEW view_with_subquery AS
SELECT 
    agent_id,
    full_name,
    commission_percentage,
    (SELECT AVG(commission_percentage) FROM agents) AS average_commission
FROM agents;

--View with Union--
CREATE VIEW view_with_union AS
SELECT agent_id AS id, full_name, phone, 'Agent' AS type
FROM agents
UNION
SELECT client_id AS id, full_name, phone, 'Client' AS type
FROM Clients;

--View on the Select from Another View--
CREATE VIEW view_from_another_view AS
SELECT agent_id, full_name, email, phone
FROM horizontal_view;

--View with Check Option--
CREATE VIEW view_with_check_option AS
SELECT agent_id, full_name, commission_percentage
FROM agents
WHERE commission_percentage > 10
WITH CHECK OPTION;

