-- Horizontal View
CREATE VIEW Horizontal_Contract_View AS
SELECT contract_id, client_id, agent_id, resort_id, offer_id, sign_date, rest_start, rest_end
FROM contracts;

SELECT * FROM Horizontal_Contract_View;

-- Vertical View
CREATE VIEW Vertical_Contract_View AS
SELECT contract_id, client_id, rest_start, rest_end
FROM contracts;

SELECT * FROM Vertical_Contract_View;

-- Mixed View
CREATE VIEW Mixed_Contract_View AS
SELECT contracts.contract_id, contracts.client_id, offers.cost
FROM contracts
JOIN offers ON contracts.offer_id = offers.offer_id
WHERE offers.cost > 1000;

SELECT * FROM Mixed_Contract_View;

-- View with Joining
CREATE VIEW Resort_Offer_View AS
SELECT resorts.name AS resort_name, offers.cost, contracts.sign_date
FROM contracts
JOIN offers ON contracts.offer_id = offers.offer_id
JOIN resorts ON contracts.resort_id = resorts.resort_id;

SELECT * FROM Resort_Offer_View;

-- View with Subquery
CREATE VIEW Contract_Count_By_Client AS
SELECT client_id, 
       (SELECT COUNT(*) FROM contracts WHERE contracts.client_id = clients.client_id) AS contract_count
FROM clients;

SELECT * FROM Contract_Count_By_Client;

-- View with Union
CREATE VIEW Client_Agent_Union_View AS
SELECT client_id, 'Client' AS type FROM clients
UNION
SELECT agent_id, 'Agent' AS type FROM agents;

SELECT * FROM Client_Agent_Union_View;

-- View on the Select from Another View
CREATE VIEW Contract_View AS
SELECT contract_id, client_id, rest_start, rest_end
FROM contracts
WHERE client_id <= 5;

CREATE VIEW Detailed_Contract_View AS
SELECT Contract_View.contract_id, Contract_View.client_id, offers.description
FROM Contract_View
JOIN offers ON Contract_View.contract_id = offers.offer_id;

SELECT * FROM Detailed_Contract_View;

-- View with Check Option
CREATE VIEW Active_Contract_View AS
SELECT contract_id, client_id, rest_start, rest_end
FROM contracts
JOIN offers ON contracts.offer_id = offers.offer_id
WHERE offers.cost > 500
WITH CHECK OPTION;

SELECT * FROM Active_Contract_View;
