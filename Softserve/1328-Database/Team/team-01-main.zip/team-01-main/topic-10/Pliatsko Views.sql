-- horizontal_view

CREATE VIEW Horizontal_view AS
SELECT comment_id, comment_text, created_at
FROM comments;

SELECT * FROM Horizontal_view;

-- vertical_view

CREATE VIEW Vertical_view AS
SELECT comment_text, created_at
FROM comments;

SELECT * FROM Vertical_view;

-- mixed_view

CREATE VIEW Mixed_view AS
SELECT comment_id, comment_text
FROM comments
WHERE created_at >= '2025-01-01';

-- join_view

CREATE VIEW Join_view AS
SELECT c.comment_id, cl.client_id
FROM comments AS c
JOIN Clients AS cl ON cl.client_id = c.client_id;

-- subquery_view

CREATE VIEW Subquery_view AS
SELECT resort_id, 
       (SELECT COUNT(*) FROM comments c2 WHERE c2.resort_id = c1.resort_id) AS total_comments
FROM comments c1
GROUP BY resort_id;

-- union_view

CREATE VIEW Union_view AS
SELECT comment_id, resort_id, client_id, comment_text
FROM comments
WHERE client_id = 21
UNION
SELECT comment_id, resort_id, client_id, comment_text
FROM comments
WHERE client_id = 23;

-- veiw_based_on_other_view

CREATE VIEW Based_on_other_view AS
SELECT * 
FROM horizontal_view
WHERE comment_id > 45;

— check_option  

CREATE VIEW Check_option AS
SELECT * FROM comments WHERE resort_id = 1
WITH CHECK OPTION;
