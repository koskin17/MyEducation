# SQL для Анализа данных с Глебом Михайловым

В этом репозитории лежат все материалы к моему <a href="https://www.udemy.com/course/draft/3937826/?referralCode=C99EC81AE75FEC9F50A2" target="_blank">курсу на Udemy</a>.

<a href="https://colab.research.google.com/drive/1Og4wDz-BELxR6izJyWFX-Wn3HVFPHE3W?usp=sharing" target="_blank">Ссылка на главный ноутбук курса на Colab</a>
